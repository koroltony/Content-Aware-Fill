function output = voteNNF(NNF, source_image, target_image)
    global patch_size;
    padsize = (patch_size-1)/2;
    pad_source_image = padarray(source_image,[padsize padsize],"symmetric");
    pad_target_image = padarray(target_image,[padsize padsize],nan,"both");

    fprintf("Voting to reconstruct the final result...\n");

    target_size = size(NNF);

    output = zeros(target_size(1)+2*padsize, target_size(2)+2*padsize, 3);
    weights = zeros(target_size(1)+2*padsize, target_size(2)+2*padsize);

    % loop through all indices in NNF and find the source patches. Then
    % combine them in the target image
    for i = 1:target_size(1)
        for j = 1:target_size(2)
            offset = NNF(i,j,:);
            yoffset = offset(1);
            xoffset = offset(2);

            % find source patch using shifted index of target patch
            source_patch = pad_source_image(i+yoffset:i+yoffset+patch_size-1,j+xoffset:j+xoffset+patch_size-1,:);
            target_patch = pad_target_image(i:i+patch_size-1,j:j+patch_size-1,:);

            distance = patchDistance(source_patch,target_patch);
            % weight smaller distances more than large distances (use eps
            % to avoid divide by 0 errors in case of tiny difference
            weight = 1 / (distance + eps); 

            % Weight the source patch by its distance and add it to the output
            output(i:i+patch_size-1,j:j+patch_size-1,:) = output(i:i+patch_size-1,j:j+patch_size-1,:) + weight * source_patch;
            % add to the cumulative weight of that pixel
            weights(i:i+patch_size-1,j:j+patch_size-1) = weights(i:i+patch_size-1,j:j+patch_size-1) + weight;
        end
    end

    % Normalize the output by dividing by the sum of weights
    output = output ./ weights;

    output = output(padsize+1:end-padsize,padsize+1:end-padsize,:);

    fprintf("Done!\n");

        function distance = patchDistance(source,target)

        % Calculate the squared difference of each channel of patches
        diff_squared = (source - target).^2;

        % Sum the squared differences over all channels without the NaN
        % values, which represents the valid region of the target
        distance = sum(diff_squared(:), 'omitnan');
    end
end

% % use the NNF to vote the source patches
% function output = voteNNF(NNF, source_image)
%     global patch_size;
%     padsize = (patch_size-1)/2;
%     pad_source_image = padarray(source_image,[padsize padsize],"symmetric");
% 
%     fprintf("Voting to reconstruct the final result...\n");
% 
%     target_size = size(NNF);
% 
%     output = zeros(target_size(1)+2*padsize, target_size(2)+2*padsize, 3);
%     avg = zeros(target_size(1),target_size(2));
% 
%     % write your code here to reconstruct the output using source image
%     % patches
% 
%     % loop through all indices in NNF and find the source patches. Then
%     % combine them in the target image
% 
%     for i = 1:target_size(1)
%         for j = 1:target_size(2)
%             offset = NNF(i,j,:);
%             yoffset = offset(1);
%             xoffset = offset(2);
% 
%             % find source patch using shifted index of target patch
%             source_patch = pad_source_image(i+yoffset:i+yoffset+patch_size-1,j+xoffset:j+xoffset+patch_size-1,:);
% 
%             % splat the patch in the output image
% 
%             output(i:i+patch_size-1,j:j+patch_size-1,:) = output(i:i+patch_size-1,j:j+patch_size-1,:) + source_patch;
% 
%             % figure out total number of overlapping patches at this pixel
%             m = patch_size;
%             n = patch_size;
% 
%             if i-(padsize+1) < 1
%                 m = patch_size - abs(i-(padsize+1));
%             elseif target_size(1)-i < padsize
%                 m = patch_size-padsize+abs(target_size(1)-i);
%             end
% 
%             if j-(padsize+1) < 1
%                 n = patch_size - abs(j-(padsize+1));
%             elseif target_size(2)-j < padsize
%                 n = patch_size-padsize+abs(target_size(2)-j);
%             end
% 
%             avg(i,j) = n*m;
%         end
%     end
%     output = output(padsize+1:end-padsize,padsize+1:end-padsize,:);
%     output = (output)./avg;
% 
%     fprintf("Done!\n");
% end
